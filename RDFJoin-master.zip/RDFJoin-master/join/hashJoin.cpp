#include<iostream>
#include<vector>
using namespace std;
class BitMap
{
public:
	BitMap(int num) :n(num), mask(0x1F), shift(5), pos(1 << mask), a(1 + n / 32, 0){}
	void set(int i)
	{
		a[i >> shift] |= (pos >> (i & mask));
	}
	int get(int i)
	{
		return a[i >> shift] & (pos >> (i & mask));
	}
	void clr(int i)
	{
		a[i >> shift] &= ~(pos >> (i & mask));
	}
private:
	int n;
	const int mask;
	const int shift;
	const unsigned int pos;
	vector<unsigned int> a;
};
void hashData(BitMap &bit,vector<int>& data)
{
    for(int i=0;i<data.size();++i)
    {
        bit.set(data[i]);
    }
}
vector<vector<int>> getResult(BitMap &bit,vector<vector<int> >& data,int index)
{
    vector<vector<int> > result;
    for(int i=0;i<data.size();++i)
    {
        if(bit.get(data[i][index]))
        {
            result.push_back(data[i]);
        }
    }
    return result;
}
vector<vector<int>> hashJoin(vector<vector<int> >& left,vector<int>& right,int index)//应用于下一个triple pattern只有一个变量的时候，也就是说这种情况下，只是增加了过滤条件
{
    BitMap bit(right.size());
    hashData(bit,right);
    return getResult(bit,left,index);
}
void print(vector<vector<int>> val)
{
    for(int i=0;i<val.size();++i)
    {
        for(int data : val[i])
            cout<<data<<" ";
        cout<<endl;
    }
}
int main()
{
    vector<vector<int> > left={{1,2,3},
                               {2,3,4},
                               {4,5,6}};
    vector<int> right={1,2,3};
    vector<vector<int>> result=hashJoin(left,right,0);
    print(result);
}
