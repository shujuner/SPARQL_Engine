#include<iostream>
#include<iomanip>
#include<cstdio>
#include<algorithm>
#include<vector>
using namespace std;
int col;
int compare(vector<int> a,vector<int> b)
{
    return a[col]<b[col];
}
int main()
{
    int m,n;
    cin>>m>>col;
    vector<vector<int>> data;
    int a,b,c;
    for(int i=0;i<m;i++)
    {
        cin>>a>>b>>c;
        data.push_back({a,b,c});
    }
    sort(data.begin(),data.end(),compare);
    for(int i=0;i<m;i++)
         cout<<data[i][0]<<' '<<data[i][1]<<' '<<data[i][2]<<endl;
    return 0;
}
