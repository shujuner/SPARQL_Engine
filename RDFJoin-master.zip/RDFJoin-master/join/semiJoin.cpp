vector<vector<int>> executeBGP(vector<Edge>& BGP)
{
    int width=0;
    if(BGP.size()>10)
        cerr<<"ERROR : Triple Pattern too many"<<endl;
    vector<vector<int> > result[10]; //目的是为了让中间结果可以重用
    rCount=0;
    for(int i=0;i<BGP.size();++i)//顺着BGP执行的顺序逐一连接triple pattern
    {
        if(BGP[i].getValNum()==2)
        {
            if(width==0)
            {
                width+=2;
                vector<int> sub=db.getPsRow(BGP[i].pre);
                vector<int> obj=db.getPoRow(BGP[i].pre);
                for(int j=0;j<sub.size();j++)
                {
                    result[rCount].push_back({sub[j],obj[j]});
                }
                rCount++;
            }
            else
            {
                width+=1;
                if(BGP[i].getSubShare())//主语是共享变量
                {
                    int col=header[BGP[i].sub];//获取主语在上一次中间结果中的列索引值
                    int sizeOfResult=result[rCount-1].size();
                    for(int j=0;j<sizeOfResult;j++)
                    {
                        int sub=result[rCount-1][j][col];//获取上一次结果中每一行中col的数值
                        vector<int> obj=db.getSpRow(sub,BGP[i].pre);
                        for(int newObj : obj)
                        {
                            vector<int> vec=result[rCount-1][j];
                            vec.push_back(newObj);
                            result[rCount].push_back(vec);
                        }
                    }
                    rCount++;
                }
                else
                {
                    int col=header[BGP[i].obj];
                    int sizeOfResult=result[rCount-1].size();
                    for(int j=0;j<sizeOfResult;j++)
                    {
                        int obj=result[rCount-1][j][col];
                        vector<int> sub=db.getOpRow(obj,BGP[i].pre);
                        for(int newSub : sub)
                        {
                            vector<int> vec=result[rCount-1][j];
                            vec.push_back(newObj);
                            result[rCount].push_back(vec);
                        }
                    }
                    rCount++;
                }
            }
        }
        else if(BGP[i].getValNum()==1)
        {
            if(BGP[i].getSubShare())//是主语变量，要扫描sp表
            {
                int col=header[BGP[i].sub];
                int sub=result[rCount-1][j][col];
                vector<int> obj=db.getSpRow(sub,BGP[i].pre);
                for(int j=0;j<result[rCount-1].size();j++)
                {
                    if(b_search(BGP[i].obj,obj))
                    {
                        result[rCount].push_back(result[rCount-1][j]);
                    }
                }
                rCount++;

            }
            else
            {
                int col=header[BGP[i].obj];
                int obj=result[rCount-1][j][col];
                vector<int> sub=db.getOpRow(obj,BGP[i].pre);
                for(int j=0;j<result[rCount-1].size();j++)
                {
                    if(b_search(BGP[i].sub,sub))
                    {
                        result[rCount].push_back(result[rCount-1][j]);
                    }
                }
                rCount++;
            }
        }
        else
        {
            cerr<<"without variable error"<<endl;
        }
        return result[rCount-1];
    }
}