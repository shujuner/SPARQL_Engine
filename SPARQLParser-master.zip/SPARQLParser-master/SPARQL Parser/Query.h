#ifndef QUERY_H_INCLUDED
#define QUERY_H_INCLUDED

#include "node.h"
#include "SPARQLParser.h"
enum TYPE { SELECT, DELETE, INSERT };

class Query {

public:
	Query();
	Query(SPARQLParser parser);
	string prefix;

	string querystring;

	// list of projections
	vector<string> projections;

	// list of nodes
	vector<Node> string_nodes;
	vector<Node> nodes;

	// list of variables
	vector<string> variables;

	TYPE type;
	int qid;
	string print();
	bool supported;
};


#endif // QUERY_H_INCLUDED
