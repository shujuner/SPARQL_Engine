#ifndef SPARQLLEXER_H_INCLUDED
#define SPARQLLEXER_H_INCLUDED

#include <string>
class SPARQLLexer
{
public:
	/// Possible tokens
	enum Token { None, Error, Eof, IRI, String, Variable, Identifier, Colon, Semicolon, Comma, Dot, Underscore, LCurly, RCurly, LParen, RParen, LBracket, RBracket, Anon, Equal, NotEqual, Less, LessOrEqual, Greater, GreaterOrEqual, At, Type, Not, Or, And, Plus, Minus, Mul, Div, Integer, Decimal, Double };

private:
	/// The input
	std::string input;
	/// The current position
	std::string::const_iterator pos;
	/// The start of the current token
	std::string::const_iterator tokenStart;
	/// The end of the curent token. Only set if delimiters are stripped
	std::string::const_iterator tokenEnd;
	/// The token put back with unget
	Token putBack;
	/// Was the doken end set?
	bool hasTokenEnd;

public:
	/// Constructor
	SPARQLLexer(const std::string& input);
	/// Destructor
	~SPARQLLexer();

	/// Get the next token
	Token getNext();
	/// Get the value of the current token
	std::string getTokenValue() const;
	/// Get the value of the current token interpreting IRI escapes
	std::string getIRIValue() const;
	/// Get the value of the current token interpreting literal escapes
	std::string getLiteralValue() const;
	/// Check if the current token matches a keyword
	bool isKeyword(const char* keyword) const;
	/// Put the last token back
	void unget(Token value) { putBack = value; }
	/// Peek at the next token
	bool hasNext(Token value);

	/// Return the read pointer
	std::string::const_iterator getReader() const { return (putBack != None) ? tokenStart : pos; }
};

#endif // SPARQLLEXER_H_INCLUDED
