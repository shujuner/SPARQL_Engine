#ifndef CONSTANTS_H_INCLUDED
#define CONSTANTS_H_INCLUDED

#define PERCENTILE
#ifndef CONSTANTS_H
#define CONSTANTS_H
#include <stdio.h>
#include <string>
#include <sstream>
#include <iostream>
#include <fstream>
#include <map>
#include <stdlib.h>
#include <vector>
#include <string.h>
#include <algorithm>
#include <set>
#include <unordered_set>
#include <queue>
#include "assert.h"
#include <sys/types.h>
#include <errno.h>
#include <sys/stat.h>
#define BUFFERSIZE 1048576 //has to be multiple of 16
#define RECORDSIZE 16
typedef struct data_block data_block_t;
struct data_block {
	char data[BUFFERSIZE];
	int ptr;
};
using namespace std;

typedef int ll;
//---------------------------------------------------------------CONSTANTS-----------------------------------------------------
const string intermediate_delim = "|";
const string part_string = "********************************************************************";
const string query_delim = "#EOQ#";
const string cmd_delimiter = "^";
const string VAR_STRING = "?#MV";
//---------------------------------------------------------------ENUMS---------------------------------------------------------
enum hash_type {
	HS,
	HO,
	RAND,
	HSO
};
enum trav_col {
	/* 0 	*/SUBJ,
	/* 1 	*/PRED,
	/* 2 	*/OBJ
};
enum PLAN_OP { SEMI_JOIN, STAR, PARALLEL, PHD_PARALLEL, PHD_SEMI_JOIN, EMPTY, FAIL };
enum PREPARE_AHEAD { PREPARE_RANDOM, PREPARE_LOCALITY, NO_PREPARE, PREPARE_LOCALITY_SUBJECT };

#endif /* CONSTANTS_H_ */




#endif // CONSTANTS_H_INCLUDED
