#ifndef UTILS_H_INCLUDED
#define UTILS_H_INCLUDED

#include "constants.h"
#include "time.h"
using namespace std;

void throwException(string exc);
bool isVariable(string const &name);
bool isLiteral(string &name);
string trim(const string & s);
double gini_coef(vector<long long>& vec);
void split_string(string& text, string delim, vector<string>& splits);
double timespec_to_double(timespec &ts);

struct dict_entry {
	string text;
	bool literal;
};

template<class T>
std::string toString(const T& t) {
	std::stringstream ss;
	ss << t;
	return ss.str();
}

template<class T>
string print_list(const vector<T>& vec, string delim) {

	string printout = "";

	for (unsigned i = 0; i < vec.size(); i++) {
		printout += toString(vec[i]);

		if (i < vec.size() - 1)
			printout += delim;
	}

	return printout;
}

int b_search(vector<dict_entry> &data, string &value);

#endif // UTILS_H_INCLUDED
