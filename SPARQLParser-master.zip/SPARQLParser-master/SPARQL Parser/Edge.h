#ifndef EDGE_H_INCLUDED
#define EDGE_H_INCLUDED
Class Edge
{
private:
    bool
}


#endif // EDGE_H_INCLUDED
