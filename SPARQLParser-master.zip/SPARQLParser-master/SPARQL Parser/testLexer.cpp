#include "SPARQLLexer.h"
#include "SPARQLParser.h"
#include "Query.h"
#include<iostream>
#include<string>
using namespace std;
int main()
{
	string prefix = "PREFIX rdf : < http ://www.w3.org/1999/02/22-rdf-syntax-ns#>  PREFIX course : < http ://www.Department0.University0.edu/>";
	string query = "select ?GivenName ?FamilyName where {?GivenName <givenNameOf> ?p .}";
	SPARQLLexer lexer(query);
    SPARQLParser parser(lexer);
    try
    {
         parser.parse();
    } catch (const SPARQLParser::ParserException& e)
    {
         cerr << "parse error: " << e.message << endl;
    }
    for (SPARQLParser::projection_iterator iter = parser.projectionBegin(), limit = parser.projectionEnd(); iter != limit; ++iter) {
		cout<<parser.getVariableName(*iter)<<endl ;
	}
	Query q(parser);


}
