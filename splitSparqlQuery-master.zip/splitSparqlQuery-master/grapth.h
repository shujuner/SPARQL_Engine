#include "variable.h"
class grapth
{
public:
    void initGrapth(string query)
    {
        vector<string> vec;
        split_query_enter(query,vec);
        for(unsigned int i=0;i<vec.size();i++)
        {
            string sub,p,obj;
            split_query_space(vec[i],sub,p,obj);
            structureGrapth(sub,p,obj);
        }
    }
    void structureGrapth(string sub,string p,string obj)
    {
        if(node_index.find(sub)==node_index.end())
        {
            node_index[sub]=nodeNum;
            rev_node_index[nodeNum]=sub;
            nodeNum++;
        }
        if(node_index.find(obj)==node_index.end())
        {
            node_index[obj]=nodeNum;
            rev_node_index[nodeNum]=obj;
            nodeNum++;
        }
        if(edge_index.find(p)==edge_index.end())
        {
            edge_index[p]=edgeNum;
            rev_edge_index[edgeNum]=p;
            edgeNum++;
        }
        nodeCount[node_index[sub]]++;
        nodeCount[node_index[obj]]++;
        Edge edge(node_index[sub],edge_index[p],node_index[obj]);
        grapthVec.push_back(edge);
    }
};
