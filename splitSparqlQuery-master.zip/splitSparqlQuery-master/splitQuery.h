#include "header.h"
void split_query_space(string query,string& sub,string& predicate,string& object)
{
    string temp="";
    int flag=1;
    for(unsigned int i=0;i<query.length();i++)
    {
        if(query[i]!=' ')
        {
            temp+=query[i];
        }
        else{
            if(flag==1)
            {
                sub=temp;
                temp="";
                flag++;
            }
            else if(flag==2)
            {
                predicate=temp;
                temp="";
                flag++;
            }
        }
    }
    object=temp;
}
void split_query_enter(string query,vector<string>& vec)
{
    string temp="";
    for(unsigned int i=0;i<query.length();i++)
    {
        if(query[i]!='\n')
        {
            temp+=query[i];
        }
        else{
            cout<<"temp= "<<temp<<endl;
            vec.push_back(temp);
            temp="";
        }
    }
}
