#include "Edge.h"
#include "splitQuery.h"
#include "header.h"
#include "grapth.h"
void traverse(int start,vector<Edge>::iterator it,vector<Edge>& subquery)
{
    if(find(keyNeiNode.begin(),keyNeiNode.end(),start) == keyNeiNode.begin())
        return;
    subquery.push_back(*it);
    int nextStart;
    if(it->startPoint==start)
    {
        nextStart=it->endPoint;
    }
    if(it->endPoint==start)
    {
        nextStart=it->startPoint;
    }
    mark[start]=1;
    vector<Edge> keyNeibor;
    vector<Edge>::iterator nextIt;
    for(nextIt=grapthVec.begin();nextIt!=grapthVec.end();nextIt++)
    {
        if(nextIt->startPoint==nextStart||nextIt->endPoint==nextStart)
        {
            keyNeibor.push_back(*nextIt);
        }
    }
    for(nextIt=keyNeibor.begin();nextIt!=keyNeibor.end();nextIt++)
    {
        if(nextIt->startPoint==nextStart&&mark[nextIt->endPoint]==0)
        {
            traverse(nextStart,nextIt,subquery);
        }
        if(nextIt->endPoint==nextStart&&mark[nextIt->startPoint]==0)
        {
            traverse(nextStart,nextIt,subquery);
        }
    }
}
int main()
{
    string sub,p,obj;
    string query="1 p1 2\n2 p2 3\n3 p3 4\n6 p4 2\n3 p5 6\n6 p6 5\n6 p7 7\n6 p8 8\n7 p9 9\n";
    //����ͼ��ʼ
    grapth g;
    g.initGrapth(query);
    //����ͼ���---------------------------------------------------
    //��ʼѡ��key Node
    int key;
    int value=0;
    for(int i=0;i<nodeNum;i++)
    {
        if(nodeCount[i]>value)
        {
            key=i;
            value=nodeCount[i];
        }
    }
    cout<<"key node= "<<rev_node_index[key]<<endl;
    //ѡ��key node����---------------------------------------------ȷ��key node��ֱ���ڽӵ�-----------
    vector<Edge>::iterator it;
    vector<Edge> keyNeibor;
    for(it=grapthVec.begin();it!=grapthVec.end();it++)
    {
        if(it->startPoint==key||it->endPoint==key)
            keyNeibor.push_back(*it);
    }
    //////////////////////////////////////////////////////////////��ʼִ�еݹ麯��������ѯ���зֽ�-----
    for(it=keyNeibor.begin();it!=keyNeibor.end();it++)
    {
        vector<Edge>::iterator tempIt;
        for(tempIt=keyNeibor.begin();tempIt!=keyNeibor.end();tempIt++)
        {
            if(tempIt->startPoint==key)
            {
                keyNeiNode.push_back(tempIt->endPoint);
            }
            if(tempIt->endPoint==key)
            {
                keyNeiNode.push_back(tempIt->startPoint);
            }
        }
        if(it->startPoint==key)
        {
            keyNeiNode.erase(remove( keyNeiNode.begin(), keyNeiNode.end(), it->endPoint ), keyNeiNode.end() );
        }
        if(it->endPoint==key)
        {
            keyNeiNode.erase(remove( keyNeiNode.begin(), keyNeiNode.end(), it->startPoint ), keyNeiNode.end() );
        }
        vector<Edge> subquery;
        traverse(key,it,subquery);
        subqueries.push_back(subquery);
    }
    ////////////////////////////////////////////////////////////////������////////////////////////////
    cout<<"subqueies size= "<<subqueries.size()<<endl;
    for(int i=0;i<subqueries.size();i++)
    {
        cout<<"��"<<i+1<<"���Ӳ�ѯΪ��"<<endl;
        for(int j=0;j<subqueries[i].size();j++)
        {
            cout<<rev_node_index[subqueries[i][j].startPoint]<<" "<<rev_edge_index[subqueries[i][j].edge]<<" "<<rev_node_index[subqueries[i][j].endPoint]<<endl;
        }
    }
    return 0;
}
