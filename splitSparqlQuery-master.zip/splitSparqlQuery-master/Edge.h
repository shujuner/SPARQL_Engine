class Edge
{
public:
    Edge(int startPoint,int edge,int endPoint)
    {
        this->startPoint=startPoint;
        this->endPoint=endPoint;
        this->edge=edge;
    }
    int startPoint;
    int endPoint;
    int edge;
};
